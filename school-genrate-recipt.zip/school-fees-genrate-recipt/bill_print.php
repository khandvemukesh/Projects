
<?php
session_start();
error_reporting(E_ERROR | E_WARNING | E_PARSE);

if(!isset($_SESSION['logged_in']))
{
 header("Location: index.php");
}

require_once ('db/config.php');

$session = $_SESSION['logged_in'];

$query  = "SELECT * FROM tbl_users WHERE id_user = '$session'";
$result = mysqli_query($con,$query)or die(mysqli_error());


?>

<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<?php

require_once ('db/config.php');
$qry_recipt="SELECT `recipt_no` FROM `bill_recipt` Order by id DESC limit 1";
$recipt_last_id=mysqli_query($con,$qry_recipt);
$red_Data=mysqli_fetch_array($recipt_last_id);
$recipt_no=$red_Data['recipt_no'];
$recipt_no++;
$studentname=$_POST['name'];
$reg=$_POST['reg'];
$class=$_POST['class'];
$date=$_POST['date'];

$deposite=$_POST['deposite'];

$particulars=" ".$_POST['diary']." ".$_POST['addmission']." ".$_POST['year']." ".$_POST['belt']." ".$_POST['tie']." ".$_POST['card'];

$tution_fess =" ".$_POST['apr']." ".$_POST['may']." ".$_POST['jun']." ".$_POST['jul']." ".$_POST['aug']." ".$_POST['sep']." ".$_POST['oct']." ".$_POST['nov']." ".$_POST['dec']." ".$_POST['jan']." ".$_POST['fed']." ".$_POST['mar'];

$stu_ins="INSERT INTO bill_recipt (`name`,`reg`,`class`,`depositer`,`date`,`recipt_no`,`particulars`,`fee_month`)
		VALUES ('$studentname','$reg','$class','$deposite','$date','$recipt_no','$particulars','$tution_fess')";

$run=mysqli_query($con,$stu_ins);
$get_fee_month="SELECT `fee_month` From `bill_recipt` WHERE recipt_no='$recipt_no'";
$fee_data=mysqli_query($con,$get_fee_month);
$fee_fetch=mysqli_fetch_array($fee_data);
$fee_string=$fee_fetch['fee_month'];
$fee_string=str_replace(" ","", $fee_string);
$length=strlen($fee_string);
$no_month=$length/3;

?>
<div class="container">
	<table class="table" border="2" style="margin-top: 30px;">
  <thead>
    <tr>
      
      <th scope="col" colspan="4" style="text-align: center;">New Betul School</th>
    </tr>
  </thead>
  <tbody>
    <tr scope="col">
       <td rowspan="2" rowspan="2" style="padding:10px 10px 10px 10px; font-size: 14px;">Student Name: <?php echo " ".$_POST['name']." / ".$_POST['reg']; ?><br/>
       	Deposit: <?php echo $_POST['deposite'];?><br/>
       	Class: <?php echo $_POST['class'];?>



       </td>
       <td colspan="3">Date: <?php echo $_POST['date']; ?></td>
   </tr>
   	<tr>
       <td colspan="3">Recipt No : <?php echo $recipt_no; ?></td>
     </tr>
   		
    <tr>
      
      <th>Particulars</th>
      <th>Fees(150)</th>
      <th>Total</th> 
      <th>Balance</th>
    </tr>
    <tr>
    	<td style='text-align:center; margin:50px 15px 50px 15px;padding:20px 15px 20px 15px;'>
    		<?php
    		if($_POST['diary']){
    			echo "".'Diary'." = 50 Rs ";
    			$amount=50;
    			echo"<br/>";

    		}
    		
    		if($_POST['tie']){
    			echo "".'Tie'." = 100 Rs ";
    			$amount=$amount+100;
    			echo"<br/>";

    		}
    		if($_POST['belt']){
    			echo "".'Belt'." = 50 Rs ";
    			$amount=$amount+50;
    			echo"<br/>";

    		}
    		
    		if($_POST['card']){
    			echo "".'I-Card'." = 100 Rs ";
    			$amount=$amount+100;
    			echo"<br/>";

    		}
    		if($_POST['addmission']){
    			echo "".'New Addmission'." = 450 Rs ";
    			$amount=$amount+450;
    			echo"<br/>";

    		}
    		if($_POST['year']){
    			echo "".'Yearly'." = 1000 Rs ";
    			$amount=$amount+1000;
    			echo"<br/>";

    		}else{
    			echo "<div style='text-align:center;'>";
    			echo "</div>";
    		}

    		?>
    		</td>

    		<td><?php echo $fee_fetch['fee_month'];?></td>
    		<td><?php echo $amount;?>+<?php echo 250*$no_month;?></td>
    		<td></td>
    		</tr>
    		<tr>
    			<td colspan="2" style="text-align: center;">Total:</td>
    			<td><?php echo $total=$amount+250*$no_month ;?> /-</td>
    			<td></td>

    		</tr>
    		<?php 
    		$upqry="UPDATE `bill_recipt` set total='$total' WHERE `recipt_no`='$recipt_no'";
    		$row=mysqli_query($con,$upqry);
    		?>
     
   
   
  </tbody>
</table>
<div class="container" style="text-align: center;">
<input type="button" onclick="window.print()" value="Print Now">&nbsp;&nbsp;&nbsp;
<a href="Dashboard.php">Go Back</a>
</div>
</div>