-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 14, 2021 at 01:02 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login-ajax`
--

-- --------------------------------------------------------

--
-- Table structure for table `bill_recipt`
--

CREATE TABLE `bill_recipt` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `reg` int(10) NOT NULL,
  `class` varchar(255) NOT NULL,
  `depositer` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `total` varchar(10) NOT NULL,
  `recipt_no` varchar(5) NOT NULL,
  `particulars` varchar(255) NOT NULL,
  `fee_month` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bill_recipt`
--

INSERT INTO `bill_recipt` (`id`, `name`, `reg`, `class`, `depositer`, `date`, `total`, `recipt_no`, `particulars`, `fee_month`) VALUES
(92, 'mukesh', 1, 'Nursery', 'father', '2021-04-02', '2250', '1', ' on on on   ', ' Apr may jun         '),
(99, 'kumar', 3, 'Nursery', 'father', '2021-04-04', '1000', '3', ' on on    ', ' Apr may          ');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id_user` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id_user`, `email`, `password`, `nama`) VALUES
(1, 'admin@rubypedia.com', 'a883bde368145d717b99c70594fd6069', 'Fika Ridaul Maulayya');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bill_recipt`
--
ALTER TABLE `bill_recipt`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `reg` (`reg`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bill_recipt`
--
ALTER TABLE `bill_recipt`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
