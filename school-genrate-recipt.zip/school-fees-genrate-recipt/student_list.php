<?php
session_start();

if(!isset($_SESSION['logged_in']))
{
 header("Location: index.php");
}

require_once ('db/config.php');

$session = $_SESSION['logged_in'];

$query  = "SELECT * FROM tbl_users WHERE id_user = '$session'";
$result = mysqli_query($con,$query)or die(mysqli_error());
$row     = mysqli_fetch_array($result);

?>

<!DOCTYPE html>
<html>
<head>
  <title>Dashboard</title>
  <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="table/dataTables.bootstrap.css">
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<nav class="navbar navbar-fixed-top" style="background-color: #f8f9fa;border-color: #f8f9fa;">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Modern Nursery School</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <div class="navbar-form navbar-right">
        <a href="logout.php" type="submit" class="btn btn-danger"><i class="fa fa-sign-out"></i> Logout</a>
          </div>
      </div>
    </nav>

<!--show---->
<div class="container" style="margin-top: 100px;">
<div class="table-responsive">
 
<table id="example1" class="table table-bordered table-striped table-hover">
	<thead>
          <tr><th colspan="9" style="text-align: center;">List Of All Student Paid Fees</th></tr>
    	   <tr>
        	   <th>Sno</th>
             <th>Recipt No</th>
			       <th>Student Name</th>
             <th>Registration No.</th>
             <th>Class</th>
             <th>Date</th>
             <th>Deposite by</th>
             <!-- <th>Particulars</th> -->
             <th>Months</th>
             <th>Total</th>

             <!-- <th>Add Fees Recipt</th> -->
         </tr>
     </thead>
     <tbody>
     <?php
	     require_once ('db/config.php');
    
	     $qry="SELECT * FROM `bill_recipt` order by id DESC";

	     $result=mysqli_query($con,$qry);
	     $i=1;
	     while($row=mysqli_fetch_array($result)){  
            $id=base64_encode($row["id"]);?>
      <tr>
         <td><?php echo $i; $i++; ?></td>
         <td><?php echo $row["recipt_no"]; ?></td>
		     <td><?php echo $row["name"]; ?></td>
         <td><?php echo $row["reg"]; ?></td>
         <td><?php echo $row["class"]; ?></td>
         <td><?php echo $row["date"]; ?></td>
         <td><?php echo $row["depositer"]; ?></td>
        <!--  <td><?php //echo $row["particulars"]; ?></td> -->
         <td><?php echo $row["fee_month"]; ?></td>
         <td><?php echo $row["total"]; ?></td>
	    
	
         <!-- <td>
           <button type="button" class="btn btn-success btn-xs" onclick="window.print()" value=""><span class='glyphicon glyphicon-book'></span>Print Bill Recipt</button> </a></td> -->
		  </tr>
	  <?php  } mysqli_close($con); ?>
     </tbody>
     <tfoot> 
     <tr>
        	   <th>Sno</th>
             <th>Recipt No</th>
             <th>Student Name</th>
             <th>Registration No.</th>
             <th>Class</th>
             <th>Date</th>
             <th>Deposite by</th>
             <!-- <th>Particulars</th> -->
             <th>Months</th>
             <th>Total</th>
             <!-- <th>Add Fees Recipt</th> -->
         </tr>
     </tfoot>
     </table>
     <button type="button" class="btn btn-success btn-xs" onclick="window.print()" value=""><span class='glyphicon glyphicon-book'></span>Print Bill Recipt</button> 
     <a href="dashboard.php"><span class='glyphicon glyphicon-book'></span>Go back</a>
     </div>
      <!--Datatable-->
 <!-- jQuery 2.1.4 -->
    
    <!-- Bootstrap 3.3.5 -->
    <!-- DataTables -->
    <script src="table/jquery.dataTables.min.js"></script>
    <script src="table/dataTables.bootstrap.min.js"></script>
    <!-- SlimScroll -->
    
    <script>
      $(function () {
        $("#example1").DataTable();
        $('#example2').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": false,
          "ordering": true,
          "info": true,
          "autoWidth": false
        });
      });
    </script>
<!--DataTables-->
<!--show-->


</div>
</div>
</div>
</div>




</body>
</html>
