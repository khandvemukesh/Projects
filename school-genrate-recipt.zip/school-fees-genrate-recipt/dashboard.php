<?php
session_start();

if(!isset($_SESSION['logged_in']))
{
 header("Location: index.php");
}

require_once ('db/config.php');

$session = $_SESSION['logged_in'];

$query  = "SELECT * FROM tbl_users WHERE id_user = '$session'";
$result = mysqli_query($con,$query)or die(mysqli_error());
$row     = mysqli_fetch_array($result);

?>

<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<nav class="navbar navbar-fixed-top" style="background-color: #f8f9fa;border-color: #f8f9fa;">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Modern Nursery School</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
        	<div class="navbar-form navbar-right">
				<a href="logout.php" type="submit" class="btn btn-danger"><i class="fa fa-sign-out"></i> Logout</a>
        	</div>
      </div>
    </nav>
<div class="container-fluid" style="margin-top: 80px">
	<div class="row">
		<div class="col-md-2">
			<div class="list-group">
			  <a href="#" class="list-group-item panel-title active" style="color:#337ab7;text-align: center;background-color: #f8f9fa;border-color: #f8f9f1;">
			    Dashboard
			  </a>
			 
			  <a href="dashboard.php" class="list-group-item"><i class="fa fa-book"></i> Add Fees</a>
			  <a href="student_list.php" class="list-group-item"><i class="fa fa-folder"></i> View Student</a>
			 
			  

			</div>
		</div>
						<!-- From Start -->


		<form method="POST" action="bill_print.php">
		<div class="col-md-10">
			<div class="panel panel-default ">
			  <div class="panel-heading">
			    <h3 class="panel-title"><span style="text-align: center;">Modern Nursery School</span></h3>
			  </div>
			  <div class="panel-body btn-primary">
			   
			   	<div class="col-md-2">
			   	<div class="form-group">
			   		<label for="studentname">Student Name</label>
			   		<input type="text" class="form-control" name="name" required>
			   	</div>
			   </div>
			   	<div class="col-md-2">
			   	<div class="form-group">
			   		<label for="regno">Reg. No.</label>
			   		<input type="number" class="form-control" name="reg" required>
			   		
			   	</div>
			   </div>
			   	<div class="col-md-3">
			   	<div class="form-group">
			   		<label for="class">Class</label>
			   		<select class="form-control" name="class" required>
			   			<option value="Nursery">Nursery</option>
			   			<option value="lkg">L.K.G</option>
			   			<option value="ukg">U.K.G</option>
			   			<option value="1">1st</option>
			   			<option value="2">2st</option>
			   			<option value="3">3st</option>
			   			<option value="4">4st</option>
			   			<option value="5">5st</option>
			   		</select>
			   	</div>
			   </div>
			   		<div class="col-md-3">
			   	<div class="form-group">
			   		<label for="Date">Date</label>
			   		<input type="date" class="form-control" name="date" required>
			   	</div>
			   </div>
			   	<div class="col-md-2">
			   	<div class="form-group">
			   		<label for="deposite by">Deposite by</label>
			   		<select class="form-control" name="deposite" required>
			   			<option value="father">Father</option>
			   			<option value="mother">Mother</option>
			   			<option value="brother">Brother</option>
			   			<option value="sister">Sister</option>


			   			<option value="uncle">Uncle</option>
			   			<option value="grand-parents">Grand Parent</option>
			   			
			   			
			   		</select>
			   		
			   	</div>
			   </div>

			  
			   


			  </div>
				</div>
		</div>
		<div class="col-md-2"></div>
		<div class="col-md-10">
			<div class="panel panel-default">
			  
			<div class="panel-body btn-success">
			<fieldset>
				  <legend style="color:#fff;">Particulars</legend>
				  <div class="col-md-2">
			   			<div class="form-group">
				  			<label >Diary&nbsp;:&nbsp;</label>
				  				<input type="checkbox" id="fname" name="diary" >
				  		</div>
				  	</div>
				  	<div class="col-md-2">
			   			<div class="form-group">
				  			<label >New Addmission&nbsp;:&nbsp;</label>
				  				<input type="checkbox" id="fname" name="addmission" >
				  		</div>
				  	</div>
				  	<div class="col-md-2">
			   			<div class="form-group">
				  			<label for="year">Yearly&nbsp;:&nbsp;</label>
				   				<input type="checkbox" id="fname" name="year">
				   			</div>
				   		</div>
				    	<div class="col-md-2">
			   				<div class="form-group">
				  			<label for="Belt">Belt&nbsp;:&nbsp;</label>
				  				<input type="checkbox" id="fname" name="belt">
				  			</div>
				  		</div>
				  		<div class="col-md-2">
			   				<div class="form-group">
				 			 <label for="tie">Tie&nbsp;:&nbsp;</label>
				   				<input type="checkbox" id="fname" name="tie">
				   			</div>
				   		</div>
				   		
				   		<div class="col-md-2">
			   				<div class="form-group">
							  	<label for="Card">Id-Card&nbsp;:&nbsp;</label>
							  		<input type="checkbox" id="fname" name="card">
							  </div>
						</div>
				  
			 </fieldset>
			</div>
		  </div>
		</div>
		<div class="col-md-2"></div>
		<div class="col-md-10">
			<div class="panel panel-default">
			  
			<div class="panel-body btn-danger">
			<fieldset>
				  <legend style="color:#fff;">Tution Fees</legend>
				  	<div class="col-md-2">
			   			<div class="form-group">
				  			<label for="apr">April&nbsp;:&nbsp;</label>
				  				<input type="checkbox" id="fname" name="apr" value="Apr" >
				  		</div>
				  	</div>
				  	<div class="col-md-2">
			   			<div class="form-group">
				  			<label for="May">May&nbsp;:&nbsp;</label>
				   				<input type="checkbox" id="fname" name="may" value="may">
				   			</div>
				   		</div>
				    	<div class="col-md-2">
			   				<div class="form-group">
				  			<label for="jun">June&nbsp;:&nbsp;</label>
				  				<input type="checkbox" id="fname" name="jun" value="jun">
				  			</div>
				  		</div>
				  		<div class="col-md-2">
			   				<div class="form-group">
				 			 <label for="jul">July&nbsp;:&nbsp;</label>
				   				<input type="checkbox" id="fname" name="jul" value="Jul">
				   			</div>
				   		</div>
				   		<div class="col-md-2">
			   				<div class="form-group">
				  				<label for="aug">August&nbsp;:&nbsp;</label>
				  					<input type="checkbox" id="fname" name="aug" value="aug">
							</div>
						</div>
				   		<div class="col-md-2">
			   				<div class="form-group">
							  	<label for="sep">September&nbsp;:&nbsp;</label>
							  		<input type="checkbox" id="fname" name="sep" value="sep">
							  </div>
						</div>
						<div class="col-md-2">
			   				<div class="form-group">
							  	<label for="oct">October&nbsp;:&nbsp;</label>
							  		<input type="checkbox" id="fname" name="oct" value="oct">
							  </div>
						</div>
						<div class="col-md-2">
			   				<div class="form-group">
							  	<label for="nov">November&nbsp;:&nbsp;</label>
							  		<input type="checkbox" id="fname" name="nov" value="nov">
							  </div>
						</div>
						<div class="col-md-2">
			   				<div class="form-group">
							  	<label for="dec">December&nbsp;:&nbsp;</label>
							  		<input type="checkbox" id="fname" name="dec" value="dec">
							  </div>
						</div>
						<div class="col-md-2">
			   				<div class="form-group">
							  	<label for="jan">January&nbsp;:&nbsp;</label>
							  		<input type="checkbox" id="fname" name="jan" value="jan">
							  </div>
						</div>
						<div class="col-md-2">
			   				<div class="form-group">
							  	<label for="feb">Fedruary&nbsp;:&nbsp;</label>
							  		<input type="checkbox" id="fname" name="fed" value="fed">
							  </div>
						</div>
						<div class="col-md-2">
			   				<div class="form-group">
							  	<label for="mar">March&nbsp;:&nbsp;</label>
							  		<input type="checkbox" id="fname" name="mar" value="mar">
							  </div>
						</div>
				  
			 </fieldset>
			</div>
		  </div>
		</div>
		<div class="col-md-2"></div>
		<div class="col-md-4"></div>
		
	<div class="col-md-2" style="text-align: center;">
			<div class="form-group">
			   		<input type="submit" name="print" value="Print bill" class="btn btn-success">
			   	</div>
	</div>
	<div class="col-md-4">
			   
			   </div>

	</form>


				
	</div>
</div>

<script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</body>
</html>